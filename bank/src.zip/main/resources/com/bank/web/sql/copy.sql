create emp_copy as

select employee_id, last_name, salary
from   employees;