package com.bank.web.util;

public class Constants {
	public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String ORACLE_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String ORACLE_ID = "bank";
	public static final String ORACLE_PASS = "oracle";
	public static final String BANK = "한빛뱅크";
}
